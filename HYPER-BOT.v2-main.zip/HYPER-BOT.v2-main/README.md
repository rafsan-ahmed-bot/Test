# ☠️ HYPER Bot v2

A **Messenger Bot** built using **Node.js** that runs on your personal Facebook account.  
Made with ❤️ by **NTKhang** & customized for extended use.
NOW IS CUSTOMISING BY RAFSAN AHMED.
---

## ✨ Features

- 📌 Auto-restart & crash recovery  
- 🛠 Easy-to-use command system  
- 🔒 Role-based permissions (admin/user)  
- ⚡ Fast & lightweight with Node.js v20  
- 📝 Configurable `config.json` for quick setup  
- 🌐 Multi-language support
- 🙂 And Add cookies on `Account.txt`
- 🎀 deploy The bot on `Render.com` suggested
